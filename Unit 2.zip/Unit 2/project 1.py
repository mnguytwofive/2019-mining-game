#Milton Nguy
#5-25-2019
from scene import *
from sound import *
import random
import notification
import math
A = Action

def cmp(a, b):
	return ((a > b) - (a < b))
	
class MyScene (Scene):
		
	def i1(self,sender):
		if self.moneh >= 100: #if you have atleast 100 balance, then you can gain the item
			play_effect('Undertale OST 021 - Dogsong.mp4', looping = True)
			self.moneh = self.moneh - 100
			self.x1 = -1		
			self.x2 = 0.01
		self.mywindow.close()		
				
	def j(self, node):
		
		for each in self.solid:
			if Point(self.p.position.x, self.p.position.y+self.p.size.h) in each.frame:
				break	#If a block is ahead/on top then it blocks the player			
		else:
			self.p.vy = 5 #if theres open space, then the player is able to jump
		"""
	def notifi(self,sender):
		self.mywindow.close()
		self.mywindow.wait_modal()
		self.mywindow2 = ui.View(width = 500, height = 500, background_color = (.7, 1.0, .96))
		self.mywindow2.present('sheet')
		
		self.b = ui.TextField(x = 0, y = 50, width = 300, height = 50, placeholder = "What do you want to be reminded?")
		self.mywindow2.add_subview(self.b)
		
		self.b1 = ui.TextField(x = 0, y = 125, width = 300, height = 50, placeholder = "How many seconds?")
		self.mywindow2.add_subview(self.b1)
		
		#self.b2 = ui.TextField(x = 0, y = 200, width = 300, height = 50, placeholder = "How many minutes?")
		#self.mywindow2.add_subview(self.b2)
		
		self.enter = ui.Button(x = 0, y = 350, width = 100, height = 150)
		self.enter.background_image = ui.Image('card:BackRed3')
		self.enter.action = self.success
		self.mywindow2.add_subview(self.enter)
		"""
		
	def success(self,sender):
		notification.schedule("Can I get one hundo", 0.1)
		
		
		
	def setup(self):
		self.ground = Node(parent=self)
		self.moneh = 0
		self.solid = []
		self.mywindow = ui.View(width = 500, height = 500, background_color = 'gray')
		
		self.item = ui.Label(frame = (0, -20, 450,100), text = "Pickaxe from a random homeless guy", font = ("Marker Felt",25), text_color = 'gold')
		self.mywindow.add_subview(self.item)
		
		self.itemim = ui.Button(frame = (0, 40, 125, 125)) 
		self.itemim.background_image = ui.Image('IMG_0651.JPG')
		self.itemim.action = self.i1
		self.mywindow.add_subview(self.itemim)
		
		self.iteminfo = ui.Label(frame = (130,50,400,100), text = "I think its good. Costs 100", font = ("Helvetica", 20), text_color = 'white')
		self.mywindow.add_subview(self.iteminfo)
		
		self.noti = ui.Button(frame = (0,370,125,125))
		self.noti.background_image = ui.Image("IMG_0661.PNG")
		self.noti.action = self.success
		self.mywindow.add_subview(self.noti)
		
		self.notiinfo = ui.Label(frame = (130,380,400,100), text = "Would you like to get notified something?", font = ("Helvetica", 15), text_color = 'white')
		self.notiinfo.action = self.success
		self.mywindow.add_subview(self.notiinfo)
		
		
		for x in range(30):
			for y in range(12):
				self.ground1 = SpriteNode('IMG_0645.JPG', position = (50*x, 50*y), size = (50,50))
				self.ground.add_child(self.ground1)
				self.solid.append(self.ground1)
				
		self.p = SpriteNode('IMG_0644.PNG', anchor_point = (0.5,0), size = (40,60), position = (self.size.w/2,550))
		self.p.vy = 1 #not a custom function so you can't put inside of SpriteNode
		self.add_child(self.p)
		
		self.shop = SpriteNode('IMG_0646.PNG', position = (50,620), size = (100,100))
		self.add_child(self.shop)
		
		self.jump = ui.Button(frame = (980,700,40,80))
		self.jump.background_image = ui.Image('plf:AlienGreen_jump')
		self.view.add_subview(self.jump)
		self.jump.action = self.j
		
		self.score = LabelNode('Money: '+str(self.moneh), parent = self, position = (950,750), color = 'white')
		
		self.times = LabelNode('There is '+str(round(self.t,2)), parent = self, position = (25, 750), color = 'white')
		
		self.x1 = -0.25 #takes four hits to destroy a block
		self.x2 = 0.3 #amount of time to disappear
		
	def update(self):
		image('IMG_0643.PNG', 0, 0, self.size.w, self.size.h)
		self.score.text = 'Bal: '+str(self.moneh) 
		self.times.text = str((int(self.t)))
		#update time/bal 64x a second if player does a certain action
				
		gy = gravity().x*15
		
		gx = -gravity().y*15
		
		self.p.position += (0,self.p.vy)
	
		#test if you have touched anything solid
		for each in self.solid:	
			if each.alpha <0.1:
				self.solid.remove(each)
				each.remove_from_parent()
				self.moneh += 5 #gain bonus money for completely destroying block
			if self.p.position in each.frame and self.p.vy < 0:
				self.p.vy = 1 #makes the player jump automatically
				self.p.position = self.p.position.x, each.frame.max_y
				break
			if self.p.position in self.shop.frame:
				self.mywindow.present('sheet')	
				self.p.position+=550,0
					
		else:	
			self.p.vy -= 0.1
			

		if abs(gx)>.05: #get to texture quickly as it can if it faces specific gravity

			self.p.texture = Texture('IMG_0644.PNG')
			if gx > 0:
				self.p.x_scale = 1

			if gx < 0:
				self.p.x_scale = -1
		
		x = self.p.position.x
		y = self.p.position.y	
									
		for each in self.solid:
			potential = x+20*cmp(gx,0) #creates the dot which determines the limit of the player when intersecting an object when facing positive/negative direction
			self.dot = Point(potential, self.p.position.y+20)
			rect(*self.dot,10,10)
			if self.dot in each.frame: #Player can't pass the stone if its touching/in the stone
				break
		else: 
			self.p.position += (gx, 0)
		for each in self.solid:
			if self.p.position in each.frame and self.p.vy < 0:
				self.vy = 0
				y = each.frame.max_y
				break		
				
		
	def touch_began(self, touch):
		if abs(gravity().y)<0.05:
			mineloc = Point(self.p.position.x, self.p.position.y-20)#Mine downwards
		else:
			mineloc = Point(self.p.position.x+30*self.p.x_scale, self.p.position.y+20)#mine left/right
		for each in self.solid:		
			if mineloc in each.frame:
				each.run_action(A.fade_by(self.x1, self.x2)) #fade by a specific number in a specific time
				self.moneh += 1 #gain money each time you mine a block
			
if __name__ == '__main__':
	run(MyScene(), show_fps=True)
